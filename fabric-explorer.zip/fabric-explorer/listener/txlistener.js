var EventEmitter = require('events').EventEmitter;
var blockListener = new EventEmitter();

blockListener.on('createBlock',function (block) {

})