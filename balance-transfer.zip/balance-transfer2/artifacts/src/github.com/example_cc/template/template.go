package main

import (
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

// SimpleChaincode example simple Chaincode implementation
type SimpleChaincode struct {
}

// SimpleChaincode example simple Chaincode implementation
func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response {
	_, args := stub.GetFunctionAndParameters()
	if len(args) != 1 {
		return shim.Error("Expecting integer value for asset holding")
	}

	fmt.Println("DO SOMETHING")

	return shim.Success(nil)
}

// example simple Chaincode implementation
func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	if function == "func1" {
		t.func1(stub, args)
	}
	// ... other functions
}

// DO TRANSACTION
func (t *SimpleChaincode) move(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	arg1 := args[0]
	// ...other args
	// TODO: will be nice to have a GetAllState call to ledger
	bytes, err := stub.GetState(arg1)
	fmt.Println("DO SOMETHING")

	bytes2 := "dates"
	err = stub.PutState(A, []byte(strconv.Itoa(Aval)))
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(nil)
}

func main() {
	err := shim.Start(new(SimpleChaincode))
	if err != nil {
		logger.Errorf("Error starting Simple chaincode: %s", err)
	}
}
